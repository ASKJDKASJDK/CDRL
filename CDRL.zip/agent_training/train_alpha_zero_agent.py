import torch
from torch import optim, nn

from agents.alpha_zero_agent import AlphaZeroAgent
from agents.mcts_agent import MCTSAgent
from networks.alphazero_networks import TinyA0_Network
from utils.agent_trainer import AgentTrainer
from utils.constants import SP_SCORE
from utils.profile import Profile
from utils._utils import get_sequences, linearize_state


class AlphaZeroAgentTrainer(AgentTrainer):
    def __init__(self, training_agent, games=0, simulations=10, rollouts=1, c=1, score=SP_SCORE, refinement=False,
                 adjust=True, data_name='SetX'):
        """
        Trainer for AlphaZero agents that shall solve the multiple sequence alignment problem
        :param training_agent: instance of the AlphaZero Solver
        :param games: number of games to play during training
        :param simulations: number of mcts-simulations to perform in each state
        :param rollouts: number of rollouts to perform per simulation
        :param c: exploration-exploitation-balancing hyperparameter to fine-tune the alignments
        :param score: score to optimize the agent for
        :param refinement: flag indicating the type of optimization
        :param data_name: name of the dataset training on
        """
        """   MCTS的基本思想:
                   MCTS 的基本原理就是向前看，模拟未来可能发生的情况，从而找出当前最优的动作。

                   AlphaGo 每走一步棋，都要用 MCTS 做成千上万次模拟，从而判断出哪个动作的胜算最大。

                   做模拟的基本思想如下。假设当前有三种看起来很好的动作。每次模拟的时候从三种动作中选出一
                   种，然后将一局游戏进行到底，从而知晓胜负。（只是计算机做模拟而已，不是真的跟对手下完一
                   局。）重复成千上万次模拟，统计一下每种动作的胜负频率，发现三种动作胜率分别是 48%、
                   56%、52%。那么 AlphaGo 应当执行第二种动作，因为它的胜算最大。以上只是 MCTS 的基本想
                   法，实际做起来有很多难点需要解决。

                   类似于你在下五子棋时，提前想好对手下一次之后的对局情况（并不是真的下）

                   AlphaZero代理培训师，应解决多序列比对问题

                   ：param training_agent:AlphaZero解算器的实例

                   ：param games：训练期间要玩的游戏数

                   ：param simulations：在每个状态下执行的MCT模拟数

                   ：param rollouts：每次模拟要执行的卷展栏数

                   ：param c：勘探开发平衡超参数以微调路线

                   ：param score：优化代理的分数

                   ：param refinement：指示优化类型的标志

                   ：param data_name:在上训练的数据集的名称
               """
        super(AlphaZeroAgentTrainer, self).__init__(
            training_agent=training_agent, games=games, score=score, refinement=refinement, data_name=data_name)

        # initialize the mcts-agent that is then used to generate the training-data
        # 初始化mcts代理，然后用于生成训练数据，模拟探路过程，并且执行过程中进行微调
        self.mcts_generator = MCTSAgent(self.training_agent.profile if self.refinement else self.sequences,
                                        simulations=simulations, rollouts=rollouts, c=c, refinement=refinement,
                                        adjust=adjust)

        # initialize some parameters for training
        # 为训练初始化一些参数
        #优化器
        self.optimizer = optim.Adam(self.training_agent.net.parameters())

        #价值的稳定性
        self.value_loss_function = nn.MSELoss()

        #分数为sp分数
        self.score = score

    def set_align_table(self, align_table):
        """
        Overrides the method from the super-class, since this trainer is not alone interacting with an environment
        :param align_table: align-table instance to store alignments in and to get them from
        """
        """

        重写超类中的方法，因为该智能体不是唯一与环境交互的人

        ：param align_table:align table实例以存储对齐并从中获取对齐

        """
        super().set_align_table(align_table)
        self.mcts_generator.set_align_table(align_table)

    def get_align_table(self):
        """
        Overrides the method from the super-class, since this trainer is not alone interacting with an environment
        Here, it's sufficient to return the MCTS-Agents' table since this contains exactly the same or even more states
        than the table from the own environment
        (proof by construction of this trainer and the usage in the "menerate-mcts-episodes"-method)
        :return: align-table used and extended in this algorithm
        """
        """

        重写超类中的方法，因为该培训师不是唯一与环境交互的人

        这里，返回MCTS代理的表就足够了，因为它包含完全相同甚至更多的状态


        （通过本培训师的结构和“menerate mcts集”方法中的使用证明）

        ：return：此算法中使用和扩展的对齐表

        """
        return self.mcts_generator.get_align_table()

    def train(self, print_progress):
        """
        Perform the main part of the training
        :param print_progress: flag indicating to print the progress to the commandline
        :return: the losses and the number of fails in the test steps
        """
        episode_loss = [0, 0]
        avg_rewards, avg_losses, avg_fails = [], [], []

        for step in range(self.games):
            if (step + 1) % self.plot_size == 0 or self.env.align_table.is_full():
                # test the progress the agent made by performing 10 alignments and evaluating the results

                # 通过执行10次比对并评估结果，测试代理的进度
                tmp = [self.env.reset() for _ in range(10)]

                #回报的计算使用sp分数
                episode_reward = sum([s[self.score] for s, _, _, _ in tmp]) * 10

                #失败的次数也存起来
                episode_fails = sum([not d for _, _, _, d in tmp]) * 10

                # print the progress
                # 打印进度
                tmp_reward, tmp_loss, tmp_fails = self.print_progress(print_progress, step, episode_reward,
                                                                      episode_loss, episode_fails)
                # 将新的回报，损失，失败次数加入平均计算
                avg_rewards.append(tmp_reward)
                avg_losses.append(tmp_loss)
                avg_fails.append(tmp_fails)
                episode_loss = [0, 0]

                # if all alignments have been found exit
                # 如果已找到所有路线，请退出
                if self.env.align_table.is_full():
                    if print_progress:
                        print("Search exited. All alignments have been visited and optimality is guaranteed.")
                    break

            # generate the training-batch for this step and learn from it
            # 生成此步骤的培训批并从中学习
            episode_loss = [e + l for e, l in zip(episode_loss, self.learn(self.generate_mcts_episode()))]

        # 返回平均回报，损失，失败次数
        return avg_rewards, avg_losses, avg_fails

    def learn(self, tmp_erb, step=0):
        """
        Learn from an self-play using, MCTS-supervised batch
        :param tmp_erb: data of the batch to train on
        :param step: step indicating the number of how often the agent has learned before
        :return: loss of the value-function and the policy approximation
        """
        """

        从使用MCTS监督批次的自我游戏中学习

        ：param tmp_erb：要训练的批次数据

        ：param step：指示代理以前学习的频率的步骤

        ：return：值函数和策略近似的损失

        """
        # extract the data from the training batch
        # 从训练批中提取数据，环境信息（包括当前状态，转移概率，下一个状态估计）
        states = torch.Tensor([s for s, _, _ in tmp_erb])
        probs = torch.Tensor([p for _, p, _ in tmp_erb])
        s_ests = torch.Tensor([e for _, _, e in tmp_erb])

        # compute what the net thinks about the data
        # 计算网络对数据的看法，用网络来进行探索，在状态中前进，不断获取反馈
        net_outputs = self.training_agent.net.forward(states)

        net_ests = net_outputs[0]
        print("net_ests(移动预测）：",net_ests)

        net_probs = net_outputs[1]
        print("net_probs(移动概率）：", net_probs)

        # compute the individual losses
        # 计算个人损失，计算价值损失和策略损失，并将其整合
        value_loss = self.value_loss_function(s_ests, net_ests)
        policy_loss = torch.diagonal(torch.matmul(-probs, net_probs.log().T)).sum()
        loss = value_loss + policy_loss
        loss = loss.sum()

        # apply these losses to the
        # 将这些损失应用于
        self.optimizer.zero_grad()
        loss.backward()
        self.optimizer.step()

        #返回的是价值损失和策略损失
        return value_loss.item(), policy_loss.item()

    def generate_mcts_episode(self):
        """
        Generate training data based on which actions the network would perform and
        what an MCTS-Supervisor thinks about the resulting states
        :return:
        """
        """

                  根据网络将执行的动作生成训练数据，以及MCTS主管对结果状态的看法

                  返回：

              """
        replay_buffer = []
        _, state, _, done = self.env.soft_reset()

        while not done:
            # evaluate the state using mcts to get move-probabilities and a state estimate
            # 使用MCT评估状态，以获得移动概率和状态估计
            probs, s_est = self.mcts_generator.get_probabilities(state)

            # use the networks actual state to select the next action
            # 使用网络实际状态选择下一个操作
            with torch.no_grad():
                action = self.training_agent.select(state)

            # append the data to the replay-buffer
            # 将数据附加到重播缓冲区
            replay_buffer.append((linearize_state(state, self.num_seqs), probs, s_est))

            # and apply the selected action to the state
            # 并将所选择的动作应用于该状态
            _, state, _, done = self.env.step(action)

            # 返回经验区
        return replay_buffer


if __name__ == "__main__":  # this file was run from the command line
    #读取数据
    f = open("../b4_oxbench_429.fasta")
    seqs = []
    for line in f:
        if not line.startswith('>'):
            seqs.append(line.replace('\n', ''))  # 换行
    f.close()
    # 合并
    sum_1 = ''
    for seq in seqs:
        sum_1 += (str(seq))
    sum_1 = sum_1.upper()

    print("#############################################")
    print("##Starting training of a actor-critic agent##")
    print("#############################################")

    #分数计算使用sp分数
    score = SP_SCORE

    # 智能体逻辑定义，根据网络生成移动概率选取动作，并最后得到状态的回报估计值
    agent = AlphaZeroAgent(sequences=seqs, network_object=TinyA0_Network)

    # 对智能体进行训练
    a0t = AlphaZeroAgentTrainer(training_agent=agent, simulations=50, adjust=True)
    # 执行
    a0t.run(progress_print=True)

    # compute the resulting multiple sequence alignment
    # 计算得到的多序列比对，根据训练结果得到最佳策略
    (best_profile, best_permutation), _ = a0t.evaluate_training()
    # 最佳分数
    reward = best_profile.score()
    # 打印对齐情况，每条序列逐一打印
    print(str(best_profile))
    # 打印分数和序列顺序
    print("Score:", reward[score], F"({best_permutation})")


