import random
from utils.agent_trainer import align_progressive
import numpy as np
import torch

from utils._utils import one_hot
from utils.agent_trainer import AgentTrainer
from utils.constants import MC_LEARN, SP_SCORE
from utils.profile import Profile
from utils._utils import linearize_state
from utils._utils import pad_vector
from collections import Counter
import math

def Entropy(DataList):
    '''
        计算随机变量 DataList 的熵
    '''
    counts = len(DataList)  # 总数量
    counter = Counter(DataList)  # 每个变量出现的次数
    prob = {i[0]: i[1] / counts for i in counter.items()}  # 计算每个变量的 p*log(p)
    H = - sum([i[1] * math.log2(i[1]) for i in prob.items()])  # 计算熵

    return H

def Count(a=0):
    B = np.zeros(a - 1)
    for i in range(a - 1):
        if i == 0:
            B[0] =(math.log2(a))
        else:
            c = np.pad(np.arange(i + 2), (0, a - i - 2))
            c=Entropy(c)
            B[a - i - 1] = c
    return B

printing = False

class FunctionTrainer(AgentTrainer):
    def __init__(self, training_agent, games=0, steps_epsilon=0, epsilon_end=0, alpha=0.001, gamma=0.9, lamb=0.1,
                 n=MC_LEARN, score=SP_SCORE, look_ahead_search=False, supported_search=False, refinement=False,
                 data_name='SetX'):
        """
        Container class holding methods used in value-function approximating agents like table and value agents
        Filling needed fields by extracting those from the agent
        :param training_agent: the agent to be trained should be already initialized
        :param games: games to play while training
        :param steps_epsilon: steps used to reduce epsilon from 1 in step 0 to EPSILON_END
        :param epsilon_end: minimal value of epsilon-parameter for epsilon-greedy learning
        :param alpha: learning_rate used to weight the loss when performing the weights update
        :param gamma: discount factor to control influence of the final reward on the computed q-values
        :param lamb: lambda value of the lambda-return methods as alternative to the n-step bootstrapping
        :param n: control for n-step temporal-difference learning or Monte-Carlo algorithms
        :param score: score to optimize the agent for
        :param look_ahead_search: bool flag to control usage of look-ahead-search to guide the training process
        :param supported_search: control flag to enable search support by an array containing all possible next states
                                 disables reselection of an previously selected action
        :param refinement: flag indicating the refinement step of a profile to be learned in this training
        :param data_name: Name of dataset the agent in trained on
        """
        """

        用于表和值代理等值函数逼近代理的容器类保持方法

        通过从代理中提取所需字段来填充所需字段

        ：param training_agent：要训练的代理应该已经初始化

        ：param games：训练时玩的游戏

        ：param steps_epsilon：用于将epsilon从步骤0中的1减少到epsilon_END的步骤

        ：param epsilon_end：epsilon贪婪学习的epsilon参数的最小值

        ：param alpha：用于在执行权重更新时对损失进行加权的learning_rate

        ：param gamma：用于控制最终奖励对计算的q值的影响的折扣系数

        ：param lamb：lambda返回方法的lambda值，作为n步引导的替代方法

        ：param n：n步时间差学习或蒙特卡洛算法的控制

        ：param score：优化代理的分数

        ：param look_ahead_search：bool标志，用于控制前瞻搜索的使用，以指导培训过程

        ：param supported_search：通过包含所有可能的下一个状态的数组启用搜索支持的控制标志

        禁用重新选择先前选定的操作

        ：param refineration：指示要在本次培训中学习的配置文件的优化步骤的标志

        ：param data_name：代理培训的数据集的名称

        """
        super(FunctionTrainer, self).__init__(
            training_agent=training_agent, games=games, steps_epsilon=steps_epsilon, epsilon_end=epsilon_end, n=n,
            score=score, look_ahead_search=look_ahead_search, supported_search=supported_search, refinement=refinement,
            data_name=data_name)

        self.alpha = alpha
        self.gamma = gamma
        self.lamb = lamb

    def act(self, state, available=None, step=0,i=0,B = np.ones(10),hidden_state=np.zeros(16)):
        """
        Selects an action based on the given input-state.
        :param state: state to select action for, must be provided in non-linearized, permutation form
        :param available: vector containing the actions that lead to non-zero reward in this step in one-hot encoding
        :param step: step in which this action is made, needed for epsilon-greediness
        :returns: the selected action
        """
        """

        根据给定的输入状态选择操作。

        ：param state：要为其选择操作的状态，必须以非线性化排列形式提供

        ：param available：包含在一个热编码中导致此步骤中非零奖励的操作的向量

        ：param step：执行此操作的步骤，用于epsilon贪婪

        ：return：所选操作

        """
        # Compute the value for epsilon depending on the step
        # 直接计算回报的熵
        # options = [
        #     align_progressive(self.env.permutation + [i], self.sequences, self.env.align_table).score()[self.score]
        #     if v == 1 else 0 for i, v in enumerate(self.env.available)]
        # HX = Entropy(options)
        # if HX ==0:
        #     epsilon=1
        # else:
        #     epsilon=HX/(math.log2(self.num_seqs))
        # 计算模拟熵以确定探索概率
        a = self.num_seqs
        b = a*500
        # 模拟退火
        # epsilon = (b - (step + 2)) / b
        # e动态
        # e = (b - (step + 2)) / b
        e = B[i % (a - 1)]
        # epsilon = e*epsilon
        # 退火加e动态
        # if (step+2) < a*60:
        #     epsilon = (b-(step + 2))/b
        # else:
        #     e = (b - (step + 2)) / b
        #     epsilon = B[i % (a - 1)]
        #     epsilon = e*epsilon
        # 原始e策略
        if step < self.steps_epsilon:
            epsilon = 1 - (1 - self.epsilon_end) * (step / self.steps_epsilon)
        else:
            epsilon = self.epsilon_end
        # depending on the epsilon value, select an action...
        if step < (self.games * 0.1) :
            if i % (a-1) == 0:
                epsilon = 1
            else:
                epsilon = e*epsilon
        # if step<10:
        #     epsilon=epsilon
        # else:
        #     epsilon=e*epsilon
        if epsilon > 0 and random.uniform(0, 1) < epsilon:
            if self.look_ahead_search and random.uniform(0, 1) < 0.5:
                action = self.look_ahead()
            else:
                # ...randomly
                action = random.choice(list(set(range(self.num_seqs)) - set(state))) - (1 if self.refinement else 0)
                action_fake, hidden_state = self.training_agent.act(hidden_state, state,
                                                               available if self.supported_search else None)
        else:
            # ...depending on the network state
            action,hidden_state = self.training_agent.act(hidden_state,state,
                                             available if self.supported_search else None)
            # if action in set(state):
            #     action = random.choice(list(set(range(self.num_seqs)) - set(state)))
        return action,hidden_state

    def train(self, print_progress):
        """
        Performs the learning process.
        :return: the returns, losses and invalid action ratios computed during the training process
            (usable for analytical and optimization tasks)
        """
        """

        执行学习过程。

        ：return：在培训过程中计算的收益、损失和无效行动比率

        （可用于分析和优化任务）

        """
        episode_reward, episode_loss, episode_fails = 0, 0, 0
        avg_rewards, avg_losses, avg_fails = [], [], []

        # play the games in the training sample selected from randomly samples game-states
        i=0
        B=Count(self.num_seqs)/math.log2(self.num_seqs)
        for step in range(self.games):
            # print the progress the model made while learning
            if (step + 1) % self.plot_size == 0 or self.env.align_table.is_full():
                tmp_reward, tmp_loss, tmp_fail = self.print_progress(print_progress, step, episode_reward, episode_loss,
                                                                     episode_fails)
                avg_rewards.append(tmp_reward)
                avg_losses.append(tmp_loss)
                avg_fails.append(tmp_fail)
                episode_reward, episode_loss, episode_fails = 0, 0, 0

                # if all alignments have been found exit
                if self.env.align_table.is_full():
                    if self.env.best_alignment == (Profile([]), None):
                        self.env.best_alignment = self.env.align_table.get_best(self.score)
                    if print_progress:
                        print("Search exited. All alignments have been visited and optimality is guaranteed.")
                    break

            game_reward, state, profile, done = self.env.soft_reset()

            # play new game
            tmp_erb = []
            while not done:
                # compute the action, perform it in the environment and add all stats to the local replay-buffer
                #计算探索次数
                if len(state) == 0:
                    hidden_state = np.zeros(16)
                    prev_action = []
                else:
                    prev_action = state[-1]
                prev_state = hidden_state
                action,hidden_state = self.act(state, available=self.env.available, step=step,i=i,B=B,hidden_state=hidden_state)
                i=i+1
                new_state = hidden_state
                game_reward, state, profile, done = self.env.step(action)

                if isinstance(prev_state, torch.Tensor):
                    prev_state = prev_state.detach().numpy()
                if isinstance(new_state, torch.Tensor):
                    new_state = new_state.detach().numpy()
                prev_input = np.concatenate((one_hot(prev_action, self.num_seqs), prev_state))
                new_input = np.concatenate((one_hot(action, self.num_seqs), new_state))
                tmp_erb.append((prev_input, action, game_reward[self.score],
                                new_input, done))

            # update reward according to the received reward
            episode_reward += game_reward[self.score]

            if not self.refinement and len(state) != self.num_seqs:
                episode_fails += 1

            # learn from replay
            episode_loss += self.learn(tmp_erb, step)

            # 输出最好的对齐结果
            if (step+1) % 500 == 0:
                our_reward = self.env.best_alignment[0].score()
                print("######################################")
                print("##当前的最优分数为：##")
                print("######################################")
                print('the best score of', (step + 1), 'is', our_reward[SP_SCORE])
        return avg_rewards, avg_losses, avg_fails
