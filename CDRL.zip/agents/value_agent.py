import numpy as np
import torch

from agents.network_solver import NetworkSolver
from networks.ffnn_networks import GenericFFNN
from utils._utils import linearize_state
from utils._utils import one_hot
from utils._utils import pad_vector


class ValueAgent(NetworkSolver):
    def __init__(self, sequences, network_object: GenericFFNN, refinement=False, network_path="networks/FFNN.txt"):
        """
        Initialize the agent to train and select the alignment steps using an simple DQN-algorithm
        :param sequences: sequences to align
        :param network_object: network-object to use for training and function approximation in the algorithm
        :param refinement: flag indicating the refinement step of a profile to be learned in this training
        :param network_path: filepath to store the final network-state in
        """
        """

        初始化代理以使用简单的DQN算法训练和选择对齐步骤

        ：参数序列：要对齐的序列

        ：param network_object：用于算法中的训练和函数近似的网络对象

        ：param refineration：表示在本次培训中学习的配置文件的优化步骤的标志

        ：param network_path：用于存储最终网络状态的文件路径

        """
        super(ValueAgent, self).__init__(sequences, network_object, refinement, network_path)
        self.net(self.num_seqs)

    def select(self, state):
        """
        select the next action according to the actual network state
        needed to override the parent method
        :param state: state to select next sequence from in non-linearized form (just as permutation)
        :return: selected action as index of next sequence
        """
        """

        根据实际网络状态选择下一个操作

        需要重写父方法

        ：param state：以非线性形式选择下一个序列的状态（就像置换）

        ：返回：所选操作作为下一个序列的索引

        """
        action,hidden_state = self.act(state2=state)
        return action

    def act(self, hidden_state = np.zeros(16), state2 = [] , available=None):
        """
        Chooses action for provided state.
        :param state: state to perform action in
        :param available: vector containing the actions that lead to non-zero reward in this step in one-hot encoding
        :returns: the action (or accordingly the sequence) to select (align) next
        """
        """

        为提供的状态选择操作。

        ：参数状态：要在其中执行操作的状态

        ：param available：包含在一个热编码中导致此步骤中非零奖励的动作的向量

        ：返回：要选择（对齐）下一步的操作（或相应的序列）

        """
        if len(state2) == 0:
            action=[]
        else:
            action = state2[-1]
        if isinstance(hidden_state, torch.Tensor):
            hidden_state = hidden_state.detach().numpy()
        c=np.concatenate((one_hot(action,self.num_seqs),hidden_state))
        c = torch.from_numpy(c)
        net_output,hidden_state = self.net.forward(c)
        output_min = net_output.min()
        vec = np.ones(self.num_seqs)
        for i in state2:
            vec[i]=0
        #全部的概率都需要大于零
        if output_min < 0:
            net_output -= output_min
        #选取最大分数的序列
        action = (net_output * torch.tensor(vec) * (torch.tensor(available) if available is not None else 1)).max(0)[1].item()

        # in case of iterative refinement, shift the actions accordingly
        # 在迭代细化的情况下，相应地移动动作
        if self.refinement:
            action -= 1

        return action,hidden_state
