import numpy as np

from agents.network_solver import NetworkSolver
from networks.alphazero_networks import TinyA0_Network
from utils._utils import linearize_state


class AlphaZeroAgent(NetworkSolver):
    def __init__(self, sequences, network_object: TinyA0_Network, refinement=False, network_path='networks/A0.txt'):
        """
        AlphaZero-Agent holding methods for the training of an AlphaZero-Agent
        :param sequences: sequence to align in this agent
        :param network_object: network-object to use to learn the function approximation in the algorithm
        :param refinement: flag indicating the refinement step of a profile to be learned in this training
        :param network_path: filepath to store the final network-state in
        """
        """

        AlphaZero代理的培训方法

        ：param sequences：要在此代理中对齐的序列

        ：param network_object：用于学习算法中函数近似的网络对象

        ：param refineration：表示在本次培训中学习的配置文件的优化步骤的标志

        ：param network_path：用于存储最终网络状态的文件路径

        """
        super().__init__(sequences, network_object, refinement, network_path)

    def select(self, state):
        """
        Select an action based on the input state
        :param state: non-linearized state to select the action for
        :return: action selected based on the probabilities got from the net
        """
        """

        根据输入状态选择操作

        ：参数：状态：选择操作的非线性状态

        ：return：根据从网络获得的概率选择的操作

        """
        # 生成移动概率
        probs = self.net.forward(linearize_state(state, self.num_seqs))[1].detach().numpy()

        # 根据网络计算出的移动概率选出对应动作
        action = np.random.choice(range(self.num_seqs), p=probs)

        #在迭代细化的情况下，相应地移动动作
        if self.refinement:
            action -= 1

        # 返回动作
        return action

    def get_state_estimate(self, state):
        """
        Estimate the state based on the actual network-state using its state-estimation output-neuron
        :param state: state to estimate
        :return: estimation of the expected reward form that state on
        """
        """

        使用其状态估计输出神经元基于实际网络状态估计状态

        ：参数：状态：要估计的状态

        ：返回：对该状态的预期回报的估计

        """
        # 计算一个状态的预期回报
        return self.net.forward(linearize_state(state, self.num_seqs))[0]
